//Program to study the significance of size and datatype of pointer
//See: ptrSizeDatatype.png

#include<stdio.h>

int main()
{
  int *ip;
  char *cp;
  double *dp;

  printf("\n----------SIZE OF POINTERS----------");
  printf("\nsize of ip : %d", sizeof(ip));
  printf("\nsize of cp : %d", sizeof(cp));
  printf("\nsize of dp : %d", sizeof(dp));


  printf("\n\n-------DEREFERENCING QUANTITY-------");
  printf("\nint pointer dereferences : %d", sizeof(*ip));
  printf("\nchar pointer dereferences : %d", sizeof(*cp));
  printf("\ndouble pointer dereferences : %d", sizeof(*dp));


  printf("\n\n-------ARITHMETIC-------");
  printf("\nint pointer : %u \t %u", ip, ip+3);
  printf("\nchar pointer: %u \t %u", cp, cp+3);
  printf("\ndouble pointer : %u \t %u", dp, dp+3);

  return 0;
}
