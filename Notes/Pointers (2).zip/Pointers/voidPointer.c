//Program to study a void pointer
//See: void.png

#include<stdio.h>

int main()
{
  int x;    //a variable
  char y;   //a variable
  double z; //a variable
  void *p;  //a generic pointer

  x = 10;   //assignment
  y = 'q';  //assignment
  z = 3.14; //assignment

  p = &x;   //refers to an int
  printf("\n x: %d", *(int*)p);    //typecast for dereferencing

  p = &y;   //refers to a char
  printf("\n y: %c", *(char*)p);   //typecast for dereferencing

  p = &z;   //refers to a double
  printf("\n z: %f", *(double*)p); //typecast for dereferencing

  return 0;
}
