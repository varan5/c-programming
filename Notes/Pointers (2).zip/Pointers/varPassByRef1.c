//Pass by reference for variables, a primary purpose of pointers.

#include<stdio.h>

void fx(int *p) //formal parameter p is a pointer and it refers to actual parameter x
{
  *p = 99;//writing into x by dereferencing p
}

int main()
{
  int x;//declaring a variable
  x = 10; //assignment

  printf("\n x: %d", x);//reading x by name

  fx(&x); //passing memory location of x as parameter to fx

  printf("\n x: %d", x);//reading x by name

  return 0;
}
