//Demonstration of Pointer

#include<stdio.h>

int main()
{
  int x;//declaring a variable
  int *p;//declaring a pointer

  x = 10; //assignment
  p = &x; //referencing

  //Hereafter, var x can be r/w as x or
  //by dereferencing p

  printf("\n x: %d", x);//reading x by name
  printf("\n x: %d", *p);//reading x by dereferencing p

  *p = 99; //Writing 99 into x by dereferencing p
   
  printf("\n x: %d", x);//reading x by name
  printf("\n x: %d", *p);//reading x by dereferencing p

  return 0;
}
