//Dynamic Memory Mangement
//Study of malloc statement
//See: Dynamic Memory Management.png

#include<stdlib.h>
#include<stdio.h>

int *fx(int n)
{
  int qty;
  int *p;
  qty = n*sizeof(int);
  //malloc:
  //Allocates memory in heap segment.
  //It allocates a continuous block of given size.
  //If allocation fails (due to oversize or size being zero) then malloc returns NULL.
  //If allocation succeeds then malloc returns the address of the memory block.
  //That address must be preserved for usage of the memory block.
  //malloc doesnt set the datatype of the memory block, so the address it returns must be typecasted and stored in a pointer of datatype which is to be set as the datatype of the memory block.
  //memory allocated using malloc contains garbage by default.

  //calloc is all similar to malloc with a difference that the memory it allocates is clear (garbage free).
  p = (int*) malloc(qty);
  return p;
}

int main()
{
  int n, i;
  int *q;

  printf("\n Enter size of array : ");
  scanf("%d", &n);//4

  q = fx(n);
  printf("Enter %d numbers ", n);

  for(i =0 ; i < n; i++)
    scanf("%d", &q[i]);

  printf("\n");
  for(i =0 ; i < n; i++)
    printf("%d ", q[i]);//q[i] == *(q+i)

  free(q);//deallocate the memory allocated using malloc/calloc

  //hereafter dont dereference q

  return 0;
}
