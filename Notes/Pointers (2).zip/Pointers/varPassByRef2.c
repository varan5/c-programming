//Swap 2 variables
//Pass by reference for variables, a primary purpose of pointers.

#include<stdio.h>

void swap(int *p1, int *p2) 
{
  int temp;
  temp = *p1;//dereference p1 to read x
  *p1 = *p2;//read y by dereferencing p2 and assign that value to x by dereferencing p1
  *p2 = temp;//read temp as assign the value to y by dereferencing p2
}

int main()
{
  int x,y;
  x = 10; //assignment
  y = 20; //assignment

  printf("\n%d %d", x,y);

  swap(&x, &y); //passing memory locations of x and y as parameters to swap

  printf("\n%d %d", x,y);

  return 0;
}
