//Program to study pointer to a pointer
//See: pointer2Pointer.png

#include<stdio.h>

int main()
{
  int x;  //a variable
  int *p; //a pointer
  int **q;//a pointer to a pointer

  x = 10; //assignment
  p = &x; //referencing (a variable)
  q = &p; //referencing (a pointer)

  //Assessing x
  printf("\nx : %d", x);//by name
  printf("\nx : %d", *p);//by dereferencing a pointer
  printf("\nx : %d", **q);//by double dereferencing a pointer to a pointer

  return 0;
}
