//Program to study pointer to an array
//See: ptrToArray.png

#include<stdio.h>

int main()
{
  int arr[7] = {10,20,30,40,50,60,70};
  int i;
  int *ptr;

  ptr = arr;//ptr = &arr[0] (referencing)

  //Apply pointer arithmetic and dereferencing
  //to traverse the array
  printf("\n");
  for(i=0; i<7; i++)
    printf(" %d", *(ptr+i));

  //FYI: 
  //As ptr = arr
  //So *(ptr+i) = *(arr+i)
  //When we write arr[i] system solves it as *(arr+i)
    
  return 0;
}
