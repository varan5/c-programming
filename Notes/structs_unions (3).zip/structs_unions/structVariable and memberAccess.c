//study of struct:
//Tasks: define, alternate name, variable create, initialize and display.
#include<stdio.h>

//define a struct by clubbing heterogeneous data.
struct Person
{
  char name[20];
  int age;
  char gender;
};
//A struct represent a custom (user defined) datatype,
//so hereafter struct Person is a datatype.

//Assign an alternate name to it (a datatype).
typedef struct Person Person;

int main()
{
  //Create and initialize variable of struct Person
  Person p = {"Vikas", 10, 'm'};

  //display it
  printf("\n{%s, %d, %c}", p.name, p.age, p.gender);

  return 0;

}
