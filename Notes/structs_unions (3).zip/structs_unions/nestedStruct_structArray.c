//Study of struct:
//Tasks: Nested Structs and Struct Array
//Implementation : Online Exam
#include<stdio.h>

struct Option
{
  int optionNumber;
  char optionText[200];
};
typedef struct Option Option;

struct TestQuestion
{
  char question[200];
  Option o1, o2, o3;//nesting
  int rightOption;
};
typedef struct TestQuestion TestQuestion;

void setQuestionPaper(TestQuestion arr[], int size)
{
  int i;
  for(i =0 ; i < size; i++)
  {
    printf("\n Enter question %d : ", i+1);
    fflush(stdin);
    gets(arr[i].question);//it is dangerous as it doesnt keep a check on input quantity

    arr[i].o1.optionNumber = 1;
    printf("\n Enter option %d : ", arr[i].o1.optionNumber);
    fflush(stdin);
    gets(arr[i].o1.optionText);//it is dangerous as it doesnt keep a check on input quantity

    arr[i].o2.optionNumber = 2;
    printf("\n Enter option %d : ", arr[i].o2.optionNumber);
    fflush(stdin);
    gets(arr[i].o2.optionText);//it is dangerous as it doesnt keep a check on input quantity

    arr[i].o3.optionNumber = 3;
    printf("\n Enter option %d : ", arr[i].o3.optionNumber);
    fflush(stdin);
    gets(arr[i].o3.optionText);//it is dangerous as it doesnt keep a check on input quantity

    printf("\n Enter the right option (1/2/3) ");
    scanf("%d", &arr[i].rightOption);

  }
}

double exam(TestQuestion arr[], int size)
{
  int score;
  int i, ch;
  double per;
  score = 0;

  for(i =0 ; i < size; i++)
  {
    printf("\n Question %d / %d", i+1, size);
    printf("\n %s", arr[i].question);
    printf("\n %d) %s", arr[i].o1.optionNumber, arr[i].o1.optionText);
    printf("\n %d) %s", arr[i].o2.optionNumber, arr[i].o2.optionText);
    printf("\n %d) %s", arr[i].o3.optionNumber, arr[i].o3.optionText);
    printf("\n Enter choice : ");
    scanf("%d", &ch);
    if(ch == arr[i].rightOption)
      score++;
  }

  per = score * 100.0 / size;
  return per;
}

int main()
{
  double per;
  TestQuestion arr[5];//questionPaper
  setQuestionPaper(arr, 5);
  per = exam(arr, 5);
  printf("Result : %f", per);

  return 0;
}
