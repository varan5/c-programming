//Study of struct:
//Tasks: passing struct variable as parameter to function: by value and by reference
#include<stdio.h>

struct Person
{
  char name[20];
  int age;
  char gender;
};
typedef struct Person Person;

//Pass by reference
void grow(Person *ptr)//ptr (a struct pointer) is the formal parameter. It is created on function call and initialized with the memory location of the actual parameter.
{
  //update age (of actual parameter) by dereferencing the pointer

  //steps:
  //1) dereference ptr to access actual parameter
  //2) application of member access operator (dot) to r/w the member
  (*ptr).age++;

  //alternate
  //infix dereferencing operator
  //applied on pointer to struct to r/w the member.
  ptr->age++;

}

//Pass by value
void displayPerson(Person per)//per (a struct variable) is the formal parameter. It is created on function call and initialized as a copy of the actual parameter.
{
  //display: per (copy of p)
  printf("\n Name : %s", per.name);
  printf("\n Age : %d", per.age);
  printf("\n Gender : %c", per.gender);
}

int main()
{
  Person p = {"Vikas", 10, 'm'};
  displayPerson(p);//call to displayPerson() with p (struct variable) as actual parameter
  grow(&p);
  displayPerson(p);//call to displayPerson() with p (struct variable) as actual parameter

  return 0;
}
