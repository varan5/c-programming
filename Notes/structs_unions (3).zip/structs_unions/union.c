//union-struct : differences.
#include<stdio.h>
#include<string.h>

struct SDemo
{
  int a;
  char b[20];
  double c;
};
typedef struct SDemo SDemo;

union UDemo
{
  int a;
  char b[20];
  double c;
};
typedef union UDemo UDemo;

int main()
{
  SDemo os;
  UDemo ou;

  printf("\n---------Memory Allocation---------");
  printf("\n Memory location of struct members : %u, %u, %u ", &os.a, os.b, &os.c);
  printf("\n Memory location of union members : %u, %u, %u ", &ou.a, ou.b, &ou.c);

  printf("\n\n---------Size of object---------");
  printf("\n Size of object of struct : %d ", sizeof(os));
  printf("\n Size of object of union : %d ", sizeof(ou));

  printf("\n\n---------Storage---------");
  os.a = 10;
  strcpy(os.b, "computer");
  os.c = 123.456;

  ou.a = 10;
  strcpy(ou.b, "computer");
  ou.c = 123.456;


  printf("\n os{%d, %s, %f}", os.a, os.b, os.c);
  printf("\n ou{%d, %s, %f}", ou.a, ou.b, ou.c);

  return 0;
}
