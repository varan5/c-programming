//Study of ternary operator

//Program to take 2 numbers from the user
//and calculate the cube of the greater number

#include<stdio.h>//source for scanf, printf, ...

int main()//program entry point
{
  int a, b, c;
  //accept 2 values from the user <keyboard entry>
  printf("Enter 2 numbers ");
  scanf("%d%d", &a, &b);//5,7; 5,3; 4,4

  //calculate the cube of the greater number
  c = a > b ? a*a*a : b*b*b;

  //output the answer
  printf("cube : %d ", c);

  return 0;
}//main
