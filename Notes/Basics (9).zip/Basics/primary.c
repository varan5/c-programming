//Primary C Program
//See: Program Data Flow.png
//See: Life of C Program.png
//See: Program to Process.png
//Refer: printf and scanf.txt
//Refer: Others->CodeBlocks Setup.txt
//Refer: Others->Running a C Program.txt

#include<stdio.h>//source of printf, scanf, ...

//a subtask of the program
void fx()//4
{
  printf(" 1 ");//5
  printf(" 2 ");//5
  printf(" 3 ");//5
}//6

//main : A function (a set of instructions)
//that defines the life (from beginning to
//the end) of the program.
int main()//1
{
  printf(" A ");//2
  printf(" B ");//2
  printf(" C ");//2
  fx(); //3 (a function call) //7
  printf(" D ");//8
  printf(" E ");//8
  return 0; //9 (STATUS: SUCCESS)
}
