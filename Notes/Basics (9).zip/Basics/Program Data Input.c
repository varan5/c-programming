//Demonstrate data input using scanf
//Refer: Program Data Input.png

#include<stdio.h>//source for scanf, printf, ...

int main()//program entry point
{
  int x, y;//2 variables

  printf("Enter a number ");
  scanf("%d", &x);

  y = x*x*x; //cal. the cube

  printf("\nCube of %d is %d", x, y);
  
  return 0;
}//main
