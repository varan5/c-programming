//swap two numbers without using a temporary variable
//see : swap.png

#include<stdio.h>

int main()//program starts here
{
  int a, b;
  a = 10;//preset data
  b = 20;//preset data

  printf(" %d %d ", a, b);

  //swap
  a = a + b;// a becomes 10 + 20 : 30
  b = a - b;// b becomes 30 - 20 : 10
  a = a - b;// a becomes 30 - 10 : 20

  printf("\n %d %d ", a, b);

  return 0;//program ends here with success status
}
