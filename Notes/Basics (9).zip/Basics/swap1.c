//swap two numbers using a temporary variable
//see : swap.png

#include<stdio.h>

int main()//program starts here
{
  int a, b, temp;

  a = 10;//preset data
  b = 20;//preset data

  printf(" %d %d ", a, b);

  //swap
  temp = a;//temp becomes a i.e. 10
  a = b;//a becomes b i.e. 20
  b = temp;//b becomes temp i.e. 10

  printf("\n %d %d ", a, b);

  return 0;//program ends here with success status
}
