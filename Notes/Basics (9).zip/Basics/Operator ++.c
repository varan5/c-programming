//Study of Operator ++
//Refer: Operator ++.png
#include<stdio.h>//source for scanf, printf, ...

int main()//program entry point
{
  int a,b,c;

  a = 10;
  b = 5;
  c = a++ * ++b;
  printf("\na: %d", a);//11
  printf("\nb: %d", b);//6
  printf("\nc: %d", c);//60

  return 0;
}//main
