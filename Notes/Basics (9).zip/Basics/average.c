//Program to calculate average of 3 numbers
//(Revision of division.)
//See: division.png

#include<stdio.h>

int main()
{
  //3 int variables
  int n1,n2,n3;

  //1 float variable
  float avg;

  n1 = 10;//preset value
  n2 = 12;//preset value
  n3 = 15;//preset value

  avg = (n1+n2+n3)/3.0;

  printf("Avg of %d, %d and %d is %.2f", n1,n2,n3,avg);

  return 0;
}//main
