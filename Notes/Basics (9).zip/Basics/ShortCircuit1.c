//Program to prove short circuit behaviour
//of the system when LHS of || is True
//Refer: ShortCircuit1.png

#include<stdio.h>

int main()
{
  int x, y;

  x = 10;
  y = 15;

  if(x++ || ++y)
    printf("Hello %d %d", x,y);//Hello 11 15
  else
    printf("Hi %d %d", x,y);
  return 0;
}
