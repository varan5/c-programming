//Program to prove short circuit behaviour
//of the system when LHS of && is False
//Refer: ShortCircuit2.png

#include<stdio.h>
int main()
{
  int x, y;

  x = 1;
  y = 15;

  if(--x && ++y)
    printf("Hello %d %d", x,y);
  else
    printf("Hi %d %d", x,y);//Hi 0 15
  return 0;
}
