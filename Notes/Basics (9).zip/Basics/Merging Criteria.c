//Study of merging criteria's
//See: Merging Criteria.png

//Program to find whether the student gets
//a certificate or a certificate with trophy
//based on marks in theory and practical


#include<stdio.h>//source for scanf, printf, ...

int main()//program entry point
{
  int t, p;
  //accept a values from the user <keyboard entry>
  printf("Enter marks in theory ");
  scanf("%d", &t);//50, 80, 10, 75
  printf("Enter marks in practical ");
  scanf("%d", &p);//90, 30, 10, 79


  if(t > 70 && p > 70)//evaluate and merge using the truth table
  { //T
    printf("\n Student gets trophy and a certificate");
  }
  else
  { //F
    printf("\n Student gets a certificate");
  }

  return 0;
}//main
