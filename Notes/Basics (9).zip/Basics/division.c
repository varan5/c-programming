//Study of division operators

//See: Life of C Program.png
//See: Header File.png
//See: Datatypes.png
//See: division.png
//See: printing variables.png

#include<stdio.h>

int main()//program starts here
{
  //declare 4 int variables
  int no1, no2, q, r;

  //print
  printf("Study of Division Operators");
  no1 = 10; //a preset value
  no2 = 6; //a preset value

  //division to get the quotient
  q = no1 / no2;
  printf("\n%d / %d = %d", no1, no2, q);

  //division to get the remainder
  r = no1 % no2;
  printf("\n%d %% %d = %d", no1, no2, r);

  return ;//program ends here with success status
}
