//Study of if-else statements
//See: Conditional Branching.png
//Refer: Conditional Branching.txt

//Program to find whether a given number is an even number or an odd number

#include<stdio.h>//source for scanf, printf, ...

int main()//program entry point
{
  int num;
  //accept a values from the user <keyboard entry>
  printf("Enter a number ");
  scanf("%d", &num);//5,7,4
  printf("\n Number : %d", num);

  if(num %2 == 0)//divide the number by 2 and test the remainder for being equal to zero
  { //T
    printf("\n It is an even number");
  }
  else
  { //F
    printf("\n It is an odd number");
  }

  printf("\n Program ends");

  return 0;
}//main
