//Combining study of ++ and if-else
#include<stdio.h>

int main()//program entry point
{
  int a, b;
  a = 10;//11
  b = 1;//0
  if(a++ * --b)
    printf("Hi");
  else
    printf("Hello");
  
  //Decoding: if(a++ * --b)
  //Order of evaluation a++, --b and *
  //a++ increments a to 11
  //Being post increment ++ would substitute original value of the operand i.e. 10
  //--b decrements b to 0
  //Being pre decrement -- would substitute updated value of the operand i.e. 0
  //Multiplication of 10 * 0 returns 0
  //0 represents False
  //Hence if block skips and else block executes.
  //Outputting Hello

  return 0;
}//main
