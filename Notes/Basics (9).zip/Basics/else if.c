//Study of "if"-"else if"-"else"
//Program to create a arithmetic calculator
//see : else if.png
//refer: Conditional Branching.txt

#include<stdio.h>

int main()//program entry point
{
  float n1, n2, ans;
  int ch;

  //input
  printf("\n Enter 2 numbers ");
  scanf("%f%f", &n1, &n2);

  //menu
  printf("\n 1. Addition ");
  printf("\n 2. Subtraction ");
  printf("\n 3. Multiplication ");
  printf("\n 4. Division ");
  printf("\n Enter Choice ");
  scanf("%d", &ch); //1 to 4 or wrong choice

  if(ch == 1)
  {//addition
    ans = n1 + n2;
    printf("\n %.2f + %.2f = %.2f ", n1, n2, ans);
  }
  else if(ch == 2)
  {//subtraction
    ans = n1 - n2;
    printf("\n %.2f - %.2f = %.2f ", n1, n2, ans);
  }
  else if(ch == 3)
  {//multiplication
    ans = n1 * n2;
    printf("\n %.2f * %.2f = %.2f ", n1, n2, ans);
  }
  else if(ch == 4)
  {//division
    ans = n1 / n2;
    printf("\n %.2f / %.2f = %.2f ", n1, n2, ans);
  }
  else
  {
    printf("\n Wrong Choice");
  }

  printf("\n Program Ends");

  return 0;
}//main
