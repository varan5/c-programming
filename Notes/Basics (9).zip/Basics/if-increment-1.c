//Combining study of ++ and if-else
#include<stdio.h>

int main()//program entry point
{
  int i;
  i =0 ;
  if(i++)
    printf("Hi %d", i);
  else
    printf("Hello %d", i);

  //Decoding : if(i++)
  //System evaluates i++
  //Increments i to 1
  //Being post increment ++ would substitute original value of the operand i.e. 0
  //0 represents False
  //Hence if block skips and else block executes.
  //Outputting Hello 1

  return 0;
}//main
