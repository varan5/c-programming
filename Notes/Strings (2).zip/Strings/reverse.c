//Program to reverse a string
//computer ---> retupmoc
//see: reverse.png

#include<stdio.h>
#include<string.h>

int slength(char str[])
{
  int q;
  q = 0;//first element
  while(str[q] != '\0') //upto last element
    q++;//increment

  return q;
}

void sreverse(char str[])
{
  int x, y;//boundaries
  char temp;//swapping
  x = 0;//lower boundary
  y = slength(str) -1;//upper boundary

  //until center
  while(x < y)
  {
    temp = str[x];
    str[x] = str[y];
    str[y] = temp;

    x++;//grows
    y--;//reduces
  }
}

int main()
{
  char str[20];//string declaration

  //scan
  printf("Enter a string ");
  scanf("%19s", str);//scan a string of max size 19 (the idea is fetch max 19 characters from stdin.)

  //print
  printf("\n String: %s", str);

  //reverse the string
  //strrev(str);
  sreverse(str);
  //print
  printf("\n String: %s", str);

  return 0;
}
