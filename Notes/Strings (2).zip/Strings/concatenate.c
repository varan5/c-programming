//Concatenate 2 strings
//See: concatenate.png

#include<stdio.h>
#include<string.h>

int slength(char str[])
{
  int q;
  q = 0;//first element
  while(str[q] != '\0') //upto last element
    q++;//increment

  return q;
}

void concatenate(char s1[], char s2[])
{
  int i, j;
  i = slength(s1);//at end of first string
  j = 0 ;//at beginning of second string

  while(s2[j] != '\0')
  {
    s1[i] = s2[j];
    i++;
    j++;
  }

  //explicitly insert '\0'
  s1[i] = '\0';
}

int main()
{
  char str1[40], str2[20];
  printf("\n Enter a String ");
  scanf("%19s", str1);
  printf("\n Enter another String ");
  fflush(stdin);//discard space, enter, whatever
  scanf("%19s", str2);

  printf("\nString1 : %s ", str1);
  printf("\nString2 : %s ", str2);

  //strcat(str1, str2); //concatenate second string to the first
  concatenate(str1, str2);

  printf("\nString1 : %s ", str1);
  printf("\nString2 : %s ", str2);

  return 0;
}
