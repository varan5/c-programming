//Togglecase (swapcase) a String
//ComPUtEr -> cOMpuTeR
//see: toggleCase.png

#include<stdio.h>

void stoggle(char str[])
{
  int i;
  for(i = 0; str[i]!='\0'; i++)
  {
    if(str[i] >=65 && str[i] <= 90)//uppercase letter
      str[i] += 32; //switch to lowercase
    else if(str[i] >=97 && str[i] <= 122)//lowercase letter
      str[i] -= 32; //switch to uppercase
  }
}

int main()
{
  char str[20];

  //scan
  printf("Enter a string ");
  scanf("%19s", str);//scan a string of max size 19 (the idea is fetch max 19 characters from stdin.)

  //print
  printf("\n String: %s", str);

  //toggle case
  stoggle(str);

  //print
  printf("\n String: %s", str);

  return 0;
}
