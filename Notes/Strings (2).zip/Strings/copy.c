//Program to implement String Copy
//See: copy.png

#include<stdio.h>
#include<string.h>

void scopy(char s2[], char s1[])
{
  int i;
  i =0 ;
  while(s1[i] != '\0')
  {
    s2[i] = s1[i];
    i++;
  }
  s2[i] = '\0';

}//scopy

int main()
{
  char s1[20];//source string
  char s2[20];//target string

  //scan
  printf("Enter a string ");
  scanf("%19s", s1);//scan a string of max size 19 (the idea is fetch max 19 characters from stdin.)

  //print
  printf("\n Source String: %s", s1);

  //copy rhs param string into lhs param string
  //strcpy(s2, s1);
  scopy(s2,s1);

  //print
  printf("\n Target String: %s", s2);

  return 0;
}
