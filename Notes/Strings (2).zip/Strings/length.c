//Program to calculate string length
#include<stdio.h>
#include<string.h>

//see: length.png

int slength(char str[])
{
  int q;
  q = 0;//first element
  while(str[q] != '\0') //upto last element
    q++;//increment

  return q;
}

int main()
{
  char str[20];//string declaration
  int x;

  //scan
  printf("Enter a string ");
  scanf("%19s", str);//scan a string of max size 19 (the idea is fetch max 19 characters from stdin.)

  //calculate string length
  //x = strlen(str);
  x = slength(str);

  //print
  printf("\n String: %s", str);
  printf("\n length: %d", x);

  return 0;
}
