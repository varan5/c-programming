//Printing the ASCII character set
//0-255
//65-90 : A to Z
//97-122 : a to z
//32 space

#include<stdio.h>

int main()
{
  int i;
  for(i =0 ; i< 256; i++)
  {
    printf("( %d %c )",i,i);
  }
  return 0;
}