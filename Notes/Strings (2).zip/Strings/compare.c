//Compare 2 strings
//See: compare.png

#include<stdio.h>
#include<string.h>

int compare(char s1[], char s2[])
{
  int i;
  int diff;
  for(i =0; s1[i]!='\0' || s2[i] !='\0' ; i++)
  {
    diff = s1[i] - s2[i];
    if(diff != 0 )
      return diff;
  }
  //diff was always zero
  return 0; //equal
}

int main()
{
  char str1[20], str2[20];
  int result;
  printf("\n Enter a String ");
  scanf("%19s", str1);
  printf("\n Enter another String ");
  fflush(stdin);//discard space, enter, whatever
  scanf("%19s", str2);

  //result = strcmp(str1, str2);
  result = compare(str1, str2);
  if(result > 0)
    printf("\n %s > %s", str1, str2);
  else if(result < 0)
    printf("\n %s > %s", str2, str1);
  else if(result == 0)
    printf("\n %s == %s", str1, str2);

  return 0;
}
