//Program to check whether a string is palindrome string or not.
//Examples of palindrome strings: mom, dad, nitin, madam, malayalam, ...
//See: palindrome.png
#include<stdio.h>

int slength(char str[])
{
  int q;
  q = 0;//first element
  while(str[q] != '\0') //upto last element
    q++;//increment

  return q;
}

int palindrome(char str[])
{
  int x, y;//boundaries
  x = 0;//lower boundary
  y = slength(str) -1;//upper boundary

  //until center
  while(x < y)
  {
    if(str[x] != str[y])
      return 0;//false

    x++;//grows
    y--;//reduces
  }
  //always equal
  return 1;//true
}

int main()
{
  char str[20];//string declaration
  int flag;

  //scan
  printf("Enter a string ");
  scanf("%19s", str);//scan a string of max size 19 (the idea is fetch max 19 characters from stdin.)

  //print
  printf("\n String: %s", str);

  //palindrome check
  flag = palindrome(str);
  if(flag == 1)
    printf("\n %s is a palindrome string ", str);
  else if(flag == 0)
    printf("\n %s is not a palindrome string ", str);
  return 0;
}
