//Program to: Declare, scan and print a string
//See: strings.png

#include<stdio.h>

int main()
{
  //string declaration
  char str[20];

  //usage: scan, print
  printf("Enter a string ");
  scanf("%19s", str);//scan a string of max size 19 (the idea is fetch max 19 characters from stdin.)
  printf("\n String: %s", str);

  return 0;
}
