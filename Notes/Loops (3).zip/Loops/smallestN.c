//Program to find the smallest of n numbers
//See: smallestN.png

#include<stdio.h>

int main()
{
  int n;//quantity
  int i;//the loop control variable
  int val;//the number
  int smallest;//the smallest

  printf("How many numbers to compare ");
  scanf("%d", &n);//say 5

  //run the loop n times
  i = 1;//start value (initialization)
  while(i <=n) //stop value (condition)
  {
    printf("\nEnter number %d ", i);
    scanf("%d", &val);//48,77,12,10,50

    if(i == 1)
      smallest = val;//48
    else
    {
      if(val < smallest)//77<48, 12<48, 10<12, 50<10
        smallest = val;//12,10
    }

    i++;//change in value (reinitialization)
  }//while

  printf("\n Smallest number is : %d", smallest);

  return 0;
}//main
