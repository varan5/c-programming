//See NestedLoops.png
#include<stdio.h>

int main()
{
  int i,j;

  //Quadratic Loop
  /*
  for(i =1 ; i<= 3; i++)
  {
    for(j =1 ; j<= 5; j++)
    {
      printf("* ");
    }//for(j
    printf("\n");
  }//for(i
  */

  for(i =1 ; i<= 5; i++)
  {
    for(j =1 ; j<= i; j++)
    {
      printf("* ");
    }//for(j
    printf("\n");
  }//for(i

  return 0;
}
