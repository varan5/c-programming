//Demonstration of for loop
//Refer: loops.png
#include<stdio.h>

int main()
{
  int i;
  //   a   b,e,h  d,g
  for(i=1; i<=10; i++)
  {//c,f
    printf("\n %d", i);
  }
  //i
  return 0;
}
