//Study of while loop
//Program to find the factors of a number
//see: loops.png
//see: factors.png

#include<stdio.h>

int main()
{
  int n;//number
  int i;//loop control variable

  printf("\n Enter a number ");
  scanf("%d", &n); //user input

  printf("\n Factors of %d are: \n", n);
  i = 1;//initialization
  while(i <= n)
  {
    if(n % i ==0)
      printf(" %d", i);

    i++;//reinitialization
  }//while
  
  return 0;
}
