//Study of while loop
//Program to generate multiplication table
//See: loops.png
//See: multiplication.png

#include<stdio.h>

int main()
{
  int i;//loop control variable
  int ans;//resultant

  i = 1;//initialization
  while(i <= 10) //criteria
  {
      ans = 7 *i;
      printf("\n 7 * %d = %d", i, ans);
      i++; //reinitialization
  }

  return 0;
}
