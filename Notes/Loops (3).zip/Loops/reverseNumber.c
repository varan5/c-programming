//Program to reverse a number
//519 ---> 915
//See: reverseNumber.png
//Analyze accroding the the values in comments

#include<stdio.h>

int main()
{
  int n;// the number
  int digit;//temporary calculation
  int reverse;//the reverse

  printf("Enter a number ");
  scanf("%d", &n);//519
  reverse = 0;

  while(n > 0)//519,51,5
  {
    //the last digit
    digit = n % 10;//9,1,5
    //merge the digit to reverse
    reverse = reverse*10 + digit;//9,91,915
    //reduce the last digit of the number
    n=n/10;//51,5,0
  }//while

  printf("\n Reverse : %d ", reverse);
  return 0;
}
