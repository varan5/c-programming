//program to add n numbers
//See: additionN.png

#include<stdio.h>

int main()
{
  int n;//quantity
  int i;//loop control variable
  int val;//the number
  int sum;

  printf("How many numbers to add ");
  scanf("%d", &n);//say 5

  i = 1;
  while(i <= n)
  {
    printf("\nEnter a number ");
    scanf("%d", &val);//7,3,10,12,6

    if(i == 1)
      sum = val;
    else
      sum = sum + val;

    i++;
  }//while

  printf("Addition : %d ", sum);

  return 0;
}//main
