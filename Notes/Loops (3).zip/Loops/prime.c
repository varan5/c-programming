//Program to find whether the given number is a prime number or not.
//See: prime.png
//See: flag.png

#include<stdio.h>

int main()
{
  int n;//the number to check for being prime
  int i;//the loop control variable
  int flag;//status indicator

  printf("Enter a number ");
  scanf("%d", &n);//20,23

  //assign an initial value to flag
  flag = 1;
  for(i=2; i<=n/2; i++)
  {
    if(n %i == 0)
    {//T
      printf("%d is not prime ", n);
      flag = 0;//status change
      break;//stop the loop
    }
  }//for

  if(flag == 1)
    printf("%d is prime ", n);

  return 0;
}
