//Program to reverse an array
//See arrReverse.png

#include<stdio.h>

void scanArray(int a[], int s)
{
  int i;
  printf("\n Enter %d values ", s);
  for(i =0 ; i< s; i++)
    scanf("%d", &a[i]);
}

void printArray(int a[], int s)
{
  int i;
  printf("\n");
  for(i =0 ; i< s; i++)
    printf("%d ", a[i]);
}

void reverseArray(int a[], int s )
{
  int x, y;
  int temp;//for swapping

  x = 0;//lower boundary
  y = s-1;//upper boundary

  while(x <y)//until they dont cross
  {
    //swap
    temp = a[x];
    a[x] = a[y];
    a[y] = temp;
    x++;//increment
    y--;//decrement
  }
}

int main()
{
  int arr[8];
  scanArray(arr, 8);
  printArray(arr, 8);
  reverseArray(arr, 8 );
  printArray(arr, 8);
  
  return 0;
}
