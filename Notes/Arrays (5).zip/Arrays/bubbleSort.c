//Implementation of BUBBLE SORT
//see: bubbleSort.png

#include<stdio.h>

void scanArray(int a[], int s)
{
  int i;
  printf("Enter %d values ", s);
  for(i =0; i< s; i++)
    scanf("%d", &a[i]);
}

void printArray(int a[], int s)
{
  int i;
  printf("\n");
  for(i =0; i< s; i++)
    printf("%d ", a[i]);
}

void bubbleSort(int a[], int s)
{
  int i,j;//loop control
  int temp;//swapping

  //dependent quadratic loop
  for(i=s-1; i>0 ; i--)
  {
    for(j =0; j<i; j++)
    {
      if(a[j] > a[j+1])
      {
        //swapping
        temp = a[j];
        a[j] = a[j+1];
        a[j+1] = temp;
      }//if
    }//for(j
  }//for(i

}//bubbleSort

int main()
{
  int arr[7];
  scanArray(arr, 7);//input
  printArray(arr, 7);//original content
  bubbleSort(arr, 7);//sort
  printArray(arr, 7);//sorted content
  return 0;
}
