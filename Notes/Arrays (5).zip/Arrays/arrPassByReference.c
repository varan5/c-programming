//Passing array as parameter to a function.
//Study of Pass by Reference
//Refer: arrPassByReference.png

#include<stdio.h>

//Pass By Reference:
//Here "a" is declared as a formal parameter to an array.
//It is an array reference.
//It gets the memory location of the array.
//Changes made to "a" updates the actual parameter array.
void fx(int a[])
{
  a[1] = 99;
}

int main()
{
  int i;//loop control
  int arr[3] = {10,20,30};

  //observe the use of array initializer
  //to assign default values to the array
  //while declaration.

  //Know that if the number of values in
  //the initializer are less than the array
  //size then the values get assigned sequentially
  //and remaining array elements become 0
  //or default to the data type (garbage free).

  //Know that providing extra values in the
  //array initializer over the array size is
  //an error because the initializer attempts
  //to write data beyond the boundary of the
  //array.

  //display the array
  printf("\n");
  for(i = 0; i<3; i++)
    printf(" %d ", arr[i]);

  fx(arr);//call to fx with arr as actual parameter

  //display the array
  printf("\n");
  for(i = 0; i<3; i++)
    printf(" %d ", arr[i]);

  return 0;
}
