//Program to demonstrate : array
//Refer: arrays.png
//See: arrOddNos.png

#include<stdio.h>
int main()
{
  //declaration
  int oddNos[6];
  int i;

  //scan
  printf("Enter 6 odd numbers: ");
  //scanf("%d", &oddNos[0]);
  //scanf("%d", &oddNos[1]);
  //scanf("%d", &oddNos[2]);
  //scanf("%d", &oddNos[3]);
  //scanf("%d", &oddNos[4]);
  //scanf("%d", &oddNos[5]);

  for(i =0 ; i<6; i++)
    scanf("%d", &oddNos[i]);

  //display

  for(i=0;i<6;i++)
  {
    if(oddNos[i] %2 == 0)
      printf("\n%d : wrong as its an even number", oddNos[i]);
    else
      printf("\n%d : an oddnumber", oddNos[i]);
  }
  return 0;
}
