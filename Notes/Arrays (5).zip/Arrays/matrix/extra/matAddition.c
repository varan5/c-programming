//Program to perform : 
//Matrix Addition
#include<stdio.h>
#define ROWS 2
#define COLS 3

void addition(int m1[][COLS], int m2[][COLS], int m3[][COLS])
{
    int i, j;
    for(i =0; i< ROWS; i++)
    {
        for(j =0; j < COLS; j++)
        {
            m3[i][j] = m1[i][j] + m2[i][j];
        }
    }
}

void scan(int mat[][COLS]) //formal parameter is a matrix reference
{
    int i, j;
    for(i =0; i< ROWS; i++)
    {
        for(j =0; j < COLS; j++)
        {
            printf("\n Enter data for mat[%d][%d] ", i, j);
            scanf("%d", &mat[i][j]);
        }
    }
}

void display(int (*p)[COLS]) //formal parameter is a matrix pointer
{
    int i, j;
    
    printf("\n");
    for(i =0 ; i< ROWS; i++)//row
    {
        printf("\n");
        for(j =0 ; j< COLS; j++)//column representation
        {
            printf(" %3d ", *(*(p+i)+j));
        }
    }

}

int main()
{
    int m1[ROWS][COLS];
    int m2[ROWS][COLS];
    int m3[ROWS][COLS];
 
    scan(m1);
    scan(m2);
    
    addition(m1,m2,m3);
    
    display(m1);
    display(m2);
    display(m3);
    
    
    
    return 0;
}