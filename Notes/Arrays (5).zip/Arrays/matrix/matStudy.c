//Study of Matrix
//See: Matrix.png
//See: AddRows.png

#include<stdio.h>

//Here formal parameter m is a matrix reference.
//It can refer to any int matrix that has 4 columns.
//The preset 4 in col dimension helps the system
//resolve  mat[i][j] as mat+i*4+j
//Hence it is mandatory.

//Here r and c are added parameters that
//carry the usable dimensions of the matrix.
void scanMat(int m[][4] , int r, int c)
{
  int i,j;
  printf("\nEnter Data\n");
  //scanning r*c
  for(i =0 ; i < r; i++)
  {
    for(j =0 ; j < c; j++)
    {
      printf("mat[%d][%d] : ",i,j);
      scanf("%d", &m[i][j]);
    }
  }
}


void rowAddition(int m[][4] , int r, int c)
{
  int i,j;
  int sum;

  for(i =0 ; i < r; i++)
  {
    sum =0;//set
    for(j =0 ; j < c-1; j++)
    {
      sum+= m[i][j];
    }
    m[i][j] = sum;//0-3:sum,1-3:sum,2-3:sum
  }
}

void printMat(int m[][4] , int r, int c)
{
  int i,j;
  for(i =0 ; i < r; i++)
  {
    printf("\n");
    for(j =0 ; j < c; j++)
    {
      printf("[%d]",m[i][j]);
    }
  }
}


int main()
{
  //Declare a matrix of 4 rows with 4 cols each
  int mat[3][4];

  //scan it
  scanMat(mat, 3, 3);
  //print it
  printMat(mat, 3, 3);
  printf("\n Adding Rows");
  //row addition (process)
  rowAddition(mat,3,4);
  //print it
  printMat(mat, 3, 4);
  return 0;
}
