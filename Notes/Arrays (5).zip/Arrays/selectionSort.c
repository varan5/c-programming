//Implementation of SELECTION SORT
//see: selectionSort.png
#include<stdio.h>

void scanArray(int a[], int s)
{
  int i;
  printf("Enter %d values ", s);
  for(i =0; i< s; i++)
    scanf("%d", &a[i]);
}

void printArray(int a[], int s)
{
  int i;
  printf("\n");
  for(i =0; i< s; i++)
    printf("%d ", a[i]);
}

void selectionSort(int a[], int s)
{
  int i, j;//loop control
  int min;//minimum (assumed and actual)
  int temp;//swapping

  for(i = 0; i<s-1; i++)
  {
    min = i; //assumed minimum
    //dependent quadratic loop
    for(j=i+1; j<s; j++)
    {
      //compare to find the actual minimum
      if(a[j] < a[min])
      {
        min = j;//select j as minimum
      }
    }//for
    //are assumed and actual minimum same or different
    if(i != min)
    {//swap
      temp = a[i];
      a[i] = a[min];
      a[min]= temp;
    }
  }//for(j
}//selectionSort

int main()
{
  int arr[7];
  scanArray(arr, 7);//input
  printArray(arr, 7);//original content
  selectionSort(arr, 7);//sort
  printArray(arr, 7);//sorted content
  return 0;
}
