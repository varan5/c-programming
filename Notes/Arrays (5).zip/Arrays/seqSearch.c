//Implementation of Sequential Search
//See seqSearch.png

#include<stdio.h>

void scanArray(int a[], int s)
{
  int i;
  printf("\nEnter %d values ",s);
  for(i =0 ; i < s; i++)
    scanf("%d", &a[i]);
}

void printArray(int a[], int s)
{
  int i;
  printf("\n");
  for(i =0; i<s; i++)
    printf("%d ", a[i]);
}

int sequentialSearch(int a[], int s, int val)
{
  int i;
  for(i =0 ; i< s; i++)
  {
    if(a[i] == val)
    {
      return i;//index of element where match to val was found
    }
  }
  return -1;//a flag value that indicates no element matched to the val
}


int main()
{
  int arr[8];
  int x;
  int flag;//status
  scanArray(arr, 8);
  printArray(arr, 8);

  printf("\nEnter the value to search : ");
  scanf("%d", &x);

  flag = sequentialSearch(arr, 8, x);
  if(flag == -1)
    printf("\n%d not found",x );
  else
    printf("\n%d found at index %d ",x, flag );

  return 0;
}
