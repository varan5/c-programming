//Program to accept marks for 7 subjects
//in an array and find the average of marks.

//See: arrMarksAvg.png
#include<stdio.h>

int main()
{
  int arr[7];//marks
  int sum; //addition
  int n = 7;//total subjects
  float avg;//average
  int i;//loop control

  //user input
  printf("Enter marks for 7 subjects: ");
  for(i =0 ; i< 7; i++)
    scanf("%d", &arr[i]);

  //addition
  sum =0;
  for(i =0 ; i<7;i++)
     sum = sum + arr[i];
 
  //average
  //Here sum is "typecasted" to a float.
  //It means that for this usage the datatype of sum will be considered as "float"
  avg = (float)sum/n;

  printf("\nTotal Marks: %d", sum);
  printf("\nAverage Marks: %.2f", avg);

  return 0;
}
