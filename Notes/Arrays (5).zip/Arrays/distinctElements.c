//Find the count of distinct elements in an array
//see: distinctElements.png
//see: seqSearch.png

#include<stdio.h>

void scanArray(int a[], int s)
{
  int i;
  printf("\nEnter %d values ",s);
  for(i =0 ; i < s; i++)
    scanf("%d", &a[i]);
}

void printArray(int a[], int s)
{
  int i;
  printf("\n");
  for(i =0; i<s; i++)
    printf("%d ", a[i]);
}

int sequentialSearch(int a[], int s, int val, int avoid)
{
  int i;
  for(i =0 ; i< s; i++)
  {
    if(a[i] == val && i != avoid)
    {
      return i;//index of element where match to val was found
    }
  }
  return -1;//a flag value that indicates no element matched to the val
}

int countDistinctElements(int a[], int s)
{
  int cnt = 0;
  int i, x;
  for(i =0 ; i< s; i++)
  {
    if( sequentialSearch(a,s, a[i], i) == -1)
      cnt++;
  }
  return cnt;
}

int main()
{
  int arr[8];
  int x;
  scanArray(arr, 8);
  printArray(arr, 8);
  x = countDistinctElements(arr,8);
  printf("\n Number of distinct elements: %d", x);
  return 0;
}
