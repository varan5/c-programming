//Implementation of BINARY SEARCH
//see: selectionSort.png
//see: binarySearch.png
#include<stdio.h>

void scanArray(int a[], int s)
{
  int i;
  printf("Enter %d values ", s);
  for(i =0; i< s; i++)
    scanf("%d", &a[i]);
}

void printArray(int a[], int s)
{
  int i;
  printf("\n");
  for(i =0; i< s; i++)
    printf("%d ", a[i]);
}

void selectionSort(int a[], int s)
{
  int i, j;//loop control
  int min;//minimum (assumed and actual)
  int temp;//swapping

  for(i = 0; i<s-1; i++)
  {
    min = i; //assumed minimum
    //dependent quadratic loop
    for(j=i+1; j<s; j++)
    {
      //compare to find the actual minimum
      if(a[j] < a[min])
      {
        min = j;//select j as minimum
      }
    }//for
    //are assumed and actual minimum same or different
    if(i != min)
    {//swap
      temp = a[i];
      a[i] = a[min];
      a[min]= temp;
    }
  }//for(j
}//selectionSort

int binarySearch(int a[], int s, int val)
{
  int x, y;//boundaries
  int mid;//mid point

  x = 0; //lower boundary
  y = s-1;//upper boundary

  //Logarithmic loop
  //efficiency : log(size)base2
  while(x <= y)
  {
    mid = (x+y)/2;
    //compare
    if(val == a[mid])
      return mid;//found
    else if(val > a[mid])
      x = mid+1;
    else if(val < a[mid])
      y = mid-1;
  }//while

  //boundaries crossed
  return -1;//not found
}


int main()
{
  int arr[16];
  int x, flag;
  scanArray(arr, 16);//input
  selectionSort(arr, 16);//sort
  printArray(arr, 16);//sorted content

  printf("Enter value to search: ");
  scanf("%d", &x);

  flag = binarySearch(arr,16,x);
  if(flag == -1)
    printf("\n%d not found ", x);
  else
    printf("\n%d found at index %d ", x,flag);

  return 0;
}
