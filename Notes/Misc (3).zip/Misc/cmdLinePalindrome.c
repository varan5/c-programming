//palindrome
#include<stdio.h>
#include<stdlib.h>
int slength(char str[])
{
  int q;
  q = 0;//first element
  while(str[q] != '\0') //upto last element
    q++;//increment

  return q;
}

int palindrome(char str[])
{
  int x, y;//boundaries
  x = 0;//lower boundary
  y = slength(str) -1;//upper boundary

  //until center
  while(x < y)
  {
    if(str[x] != str[y])
      return 0;//false

    x++;//grows
    y--;//reduces
  }
  //always equal
  return 1;//true
}

int main(int argc, char *argv[])
{
  int flag;
  if(argc != 2)
  {
    printf("Wrong number of arguments");
    printf("\nUsage: palindrome <string>");
    exit(0);
  }

  //palindrome check
  flag = palindrome(argv[1]);
  if(flag == 1)
    printf("\n%s is a palindrome string ", argv[1]);
  else if(flag == 0)
    printf("\n%s is not a palindrome string ", argv[1]);
  return 0;
}
