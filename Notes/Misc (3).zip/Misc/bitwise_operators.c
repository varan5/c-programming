//Study of bitwise operators
//See: showbits.png
//See: bitwise_operators.png
#include<stdio.h>
void showBits(unsigned int n)
{
  int i;
  int bits[32]= {};
  printf("\nnumber : %u ", n);
  printf("\nbits: ");

  i = 31;//last
  while(n > 0)
  {
    bits[i] = n %2;//1,1,0,0,1
    n = n /2;//19,9,4,2,1,0
    i--;//reverse order
  }

  for(i =0 ; i < 32; i++)
    printf("%d",bits[i]);
}

int main()
{
  unsigned int x;
  //x = 19<<2;
  //x = 19 >> 2;
  //x = ~19;
  //printf("x: %u", x);
  //printf("\n------------------");
  //showBits(19);
  //showBits(x);
  //printf("\n------------------");

  //x = 19 & 7;
  //x = 19 | 7;
  x = 19 ^ 7;
  printf("x: %u", x);
  printf("\n------------------");
  showBits(19);
  showBits(7);
  showBits(x);
  printf("\n------------------");

  return 0;
}
