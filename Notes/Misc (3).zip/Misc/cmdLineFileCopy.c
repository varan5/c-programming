//File Copy
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
  int data;
  FILE *fp1, *fp2;

  if(argc != 3)
  {
    printf("Wrong number of arguments");
    printf("\nUsage: FileCopy <src> <trgt>");
    exit(0);
  }

  //open the source file for reading in binary mode.
  //file must exist otherwise open fails and fopen returns NULL.
  fp1 = fopen(argv[1], "rb");
  //open the target file for writing in binary mode.
  //file will be created or overwritten.
  fp2 = fopen(argv[2], "wb");

  if(fp1 == NULL || fp2 == NULL)
  {
    printf("\nFile Access Error");
    exit(0);
  }

  //files are open, copy!!!
  while( (data = fgetc(fp1)) != -1)
    fputc(data, fp2);

  fclose(fp1);
  fclose(fp2);

  printf("\nFile Copied");

  return 0;
}
