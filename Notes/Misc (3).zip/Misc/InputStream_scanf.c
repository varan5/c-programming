//input stream and scanf
#include<stdio.h>

int main()
{
  int x, y;
  int sum;
  printf("Enter a number ");
  scanf("%d", &x);//12 <space> 15
  printf("Enter another number ");
  //scanf("%d", &y);//15 is treated as decimal value and is fetched, theres no blocking for keyboard input.
  fflush(stdin);//space 15 gets discarded
  scanf("%d", &y);//blocks for new input

  sum = x +y;
  printf("%d + %d = %d ", x,y, sum);

  return 0;
}
