//multiplication

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
  int i;//loop control variable
  float n,ans;//resultant

  if(argc != 2)
  {
    printf("Wrong number of arguments");
    printf("\nUsage: multiplication <number>");
    exit(0);
  }

  n = atof(argv[1]); //string to float conversion
  i = 1;//initialization
  while(i <= 10) //criteria
  {
      ans = n *i;
      printf("\n %.2f * %d = %.2f",n, i, ans);
      i++; //reinitialization
  }

  return 0;
}
