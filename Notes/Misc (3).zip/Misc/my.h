//conditional compilation
//compile the following code between #ifndef and #endif
//only if a macro named dfjh234Q@HDJH is not defined.

#ifndef dfjh234Q@HDJH
#define dfjh234Q@HDJH 1

//variable (global)
int z = 100;

int square(int x)
{
 return x*x;
}

int cube(int x)
{
  return x*x*x;
}

#endif