#include<stdio.h>

void fx()
{
  auto int x= 10; //equivalent to int x;
  static int y= 10;
  x++;//10 - 11
  y++;//10 - 11 - 12 - 13
  printf("\n%d %d",x, y);
}

int main()
{
  fx();
  fx();
  fx();
  return 0;
}
