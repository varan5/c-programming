/*
Program to study : global variables
Refer : Global.txt
See : Global.png
*/

#include<stdio.h>

int x, y; //global variables

void fx()
{
  //int y; //will shadow the global y
  y = x*x*x;
}

int main()
{
  printf("Enter a number ");
  scanf("%d", &x);
  fx();
  printf("\n Cube of %d is %d ", x, y);
  return 0;
}

