//Study of Preprocessor directives
#include<stdio.h>
#include<my.h>
#include<my.h>

//macro: Token replacement tool.
//On compilation all occurrences of PI
//will be replaced with value 3.14
#define PI 3.14
#define MIN(N,M) N<M?N:M
#define START int main()

START
{
  #undef START //hereafter macro START is not defined
  int a, b, c;
  extern int z; //Redeclaration for readers convenience. Technically it means that z being declared here is defined by an external module.
  a = MIN(10,z);//a = N<M?N:M  where N:10 and M:z
  b = square(a);
  c = cube(a);

  printf("\n number : %d ", a);
  printf("\n square : %d ", b);
  printf("\n cube : %d ", c);
  printf("\n z: %d", z);

  return 0;
}
