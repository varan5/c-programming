//Program Data - File : R/W
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
  int i1, i2;
  char str1[20], str2[20];
  double d1, d2;

  FILE *fp;
  fp = fopen("d:/prgData.txt", "wb+");

  if(fp == NULL)
  {
    printf("File Open Failed ");
    exit(0);
  }

  //set values
  i1 = 399; //prg data
  strcpy(str1, "this_is_my_computer");//prg data
  d1 = 3.14;//prg data

  //writing
  fprintf(fp, "%d\n%s\n%lf\n", i1, str1, d1);

  //Reset the file pointer to BOF
  rewind(fp);

  //reading
  fscanf(fp, "%d\n%s\n%lf\n", &i2, str2, &d2);

  //cross check
  printf("\n %d %d", i1, i2);
  printf("\n %s %s", str1, str2);
  printf("\n %lf %lf", d1, d2);


  //close the file
  fclose(fp);

  return 0;
}
