//Program string i/o : fgets and fputs
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
  char fileContent[100];
  char userInput[100];
  char ch;

  FILE *fio;
  //open a file in append-read mode
  fio = fopen("d:/data.txt", "a+");
  //check open status
  if(fio == NULL)
  {
    printf("File Open Failed");
    exit(0);
  }

  //read old file content
  while(fgets(fileContent,100,fio))
  {
    fputs(fileContent, stdout);
  }

  //ask the user for more input
  do
  {
    printf("\nDo you want to add data (y/n) ");
    fflush(stdin);
    scanf("%c", &ch);
    if(ch == 'y' || ch == 'Y')
    {
      //fetch input
      printf("\n Enter the string to add: \n");
      fflush(stdin);
      fgets(userInput, 100, stdin);
      //write into the file
      fputs(userInput, fio);
    }
  }while(ch == 'y' || ch == 'Y');

  //file close
  fclose(fio);
  return 0;
}


/*
About fgets
---------------
fgets is used to fetch(read) strings from
a source stream.
It takes 3 parameters:
* String (buffer) to load the fetched data in.
* Max limit to fetch (n causes fetch of n-1 characters). In case enter is encountered then fetch stops.
* Source stream.
Know that the input delimiter (enter) is treated as data and is loaded into the string.
Also that at EOF it returns NULL.

About fputs
---------------
fputs is used to write string into a target stream.
It takes 2 parameters:
* String (buffer) to fetched data from.
* Target stream to write into.

*/
