//File Handling
#include<stdio.h>
#include<stdlib.h>

int main()
{
  int data;
  FILE *fp;
  //open the file d:/a.txt for reading in text mode.
  //file must exist otherwise open fails and fopen returns NULL.
  fp = fopen("d:/a.txt", "r");
  if(fp == NULL)
  {
    printf("\n File doesnt exists");
    exit(0);
  }

  //file is open for reading
  //fetch data using fgetc

  //fgetc fetches 1 byte of data from the file/stream.
  //File read pointer is auto advanced to the next position.
  //ASCII value of the read byte is returned.
  //-1 is returned in case fgetc encounters EOF.

  while( (data = fgetc(fp)) != -1)
    printf("%c", data);

  //close the file
  fclose(fp);

  return 0;
}
