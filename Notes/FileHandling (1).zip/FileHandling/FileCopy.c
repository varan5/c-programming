//File Copy
#include<stdio.h>
#include<stdlib.h>

int main()
{
  int data;
  FILE *fp1, *fp2;
  char src[20];
  char trgt[20];


  printf("Enter source file : ");
  fflush(stdin);
  gets(src);
  printf("Enter target file : ");
  fflush(stdin);
  gets(trgt);

  //open the source file for reading in binary mode.
  //file must exist otherwise open fails and fopen returns NULL.
  fp1 = fopen(src, "rb");
  //open the target file for writing in binary mode.
  //file will be created or overwritten.
  fp2 = fopen(trgt, "wb");

  if(fp1 == NULL || fp2 == NULL)
  {
    printf("\n Copy Failed");
    exit(0);
  }

  //files are open, copy!!!
  while( (data = fgetc(fp1)) != -1)
    fputc(data, fp2);

  //fputc(data, stream)
  //writes one byte of data to the stream/file.
  //close the files
  fclose(fp1);
  fclose(fp2);

  printf("File Copied");

  return 0;
}
