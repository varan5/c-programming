//A puzzle game (Micro Project) : TicTacToe
#include<stdio.h>

void initalizeBoard(char mat[][3], int r, int c)
{
  int i,j;
  for(i=0 ; i<r; i++)
    for(j=0; j<c; j++)
      mat[i][j] = ' ';//a space
}//initializeBoard

void displayBoard(char mat[][3], int r, int c)
{
  int i,j;

  for(i=0 ; i<r; i++)
  {
    printf("\n");
    for(j=0; j<c; j++)
      printf("[%c]", mat[i][j]);
  }
}//displayBoard

int isFull(char mat[][3], int r, int c)
{
  int i,j;
  for(i=0 ; i<r; i++)
    for(j=0; j<c; j++)
      if(mat[i][j] == ' ')//a space
        return 0;//false

  return 1;//true
}//isFull
int validateMove(char mat[][3], int r, int c, int x, int y)
{
  if( x < 0 || x >=r)
    return 0;//false
  else if( y < 0 || y >=c)
    return 0;//false
  else if( mat[x][y] != ' ')
    return 0;//false

  return 1;//true
}

int checkWins(char mat[][3], int r, int c, char sym)
{
  int i;

  //3 rows matched
  for(i =0 ; i < r; i++)
    if(mat[i][0] == sym && mat[i][1] == sym && mat[i][2] == sym)
        return 1;
  //3 cols matched
  for(i =0 ; i < c; i++)
    if(mat[0][i] == sym && mat[1][i] == sym && mat[2][i] == sym)
        return 1;

  //diagonal matched
  if(mat[0][0] == sym && mat[1][1] == sym && mat[2][2] == sym)
        return 1;

  //reversed diagonal matched
  if(mat[0][2] == sym && mat[1][1] == sym && mat[2][0] == sym)
        return 1;

  return 0;//false
}

void ticTacToe()
{
  char board[3][3];
  char player1[20], player2[20];
  char symbol1, symbol2;
  int current, x, y, flag;

  printf("\nEnter name of player1: ");
  fflush(stdin);
  scanf("%19s", player1);
  symbol1 = 'X';

  printf("\nEnter name of player2: ");
  fflush(stdin);
  scanf("%19s", player2);
  symbol2 = 'O';

  printf("\nSymbol for %s : %c", player1, symbol1);
  printf("\nSymbol for %s : %c", player2, symbol2);

  initalizeBoard(board, 3, 3);
  current = 1;
  flag = 0;//draw

  while(! isFull(board, 3,3))
  {
    displayBoard(board, 3, 3);
    if(current == 1)
    {
      printf("\n%s(%c) plays: ", player1, symbol1);
      printf("\nEnter row(0-2) : ");
      scanf("%d", &x);
      printf("Enter col(0-2) : ");
      scanf("%d", &y);

      if(validateMove(board,3,3,x,y))
      {//valid move, update the board
          board[x][y] = symbol1;
          if(checkWins(board, 3,3, symbol1))
          {
            displayBoard(board,3,3);
            printf("\n%s(%c) wins!!!", player1,symbol1);
            flag = 1;
            break;
          }
          current = 2;
      }
      else
      {
        printf("\nInvalid Move, play again");
      }
    }
    else if(current == 2)
    {
      printf("\n%s(%c) plays: ", player2, symbol2);
      printf("\nEnter row(0-2) : ");
      scanf("%d", &x);
      printf("Enter col(0-2) : ");
      scanf("%d", &y);

      if(validateMove(board,3,3,x,y))
      {//valid move, update the board
          board[x][y] = symbol2;
          if(checkWins(board, 3,3, symbol2))
          {
            displayBoard(board,3,3);
            printf("\n%s(%c) wins!!!", player2,symbol2);
            flag = 1;
            break;
          }
          current = 1;
      }
      else
      {
        printf("\nInvalid Move, play again");
      }
    }
  }//while

  if(flag == 0)
  {
    displayBoard(board, 3,3);
    printf("\nGame Draw!!!");
  }




}//ticTacToe

int main()
{
  char ch;
  do
  {
    ticTacToe();

    printf("\nDo you want to play again? (y/n) ");
    fflush(stdin);
    scanf("%c", &ch);
  }while(ch == 'y' || ch == 'Y');

  return 0;
}